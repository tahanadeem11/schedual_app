'use client';

import { SessionProvider } from "next-auth/react";
import { AuthProvider } from "@/contexts/AuthContext";
import { Layout } from '@/components/layout/Layout';
import { Dashboard } from '@/components/dashboard/Dashboard';

export default function Home() {
  return (
    <SessionProvider>
      <AuthProvider>
        <Layout>
          <Dashboard />
        </Layout>
      </AuthProvider>
    </SessionProvider>
  );
}
