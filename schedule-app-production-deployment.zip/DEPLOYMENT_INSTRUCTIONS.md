# Production Deployment Instructions

## Quick Start

1. **Install Dependencies**
   `ash
   npm install
   `

2. **Set Environment Variables**
   Create a .env.local file with:
   `env
   GOOGLE_CLIENT_ID=your-google-client-id.apps.googleusercontent.com
   GOOGLE_CLIENT_SECRET=your-google-client-secret
   NEXTAUTH_URL=https://yourdomain.com
   NEXTAUTH_SECRET=your-secret-key
   NODE_ENV=production
   `

3. **Build and Start**
   `ash
   npm run build
   npm start
   `

## Deployment Platforms

### Vercel (Recommended)
1. Push to GitHub
2. Import in Vercel
3. Set environment variables
4. Deploy

### Netlify
1. Connect repository
2. Set build command: npm run build
3. Set publish directory: .next
4. Add environment variables
5. Deploy

### Railway
1. Connect GitHub repository
2. Add environment variables
3. Deploy

## Documentation
- REAL_GOOGLE_INTEGRATION.md - Complete integration guide
- ENVIRONMENT_SETUP.md - Environment configuration
- GOOGLE_SETUP.md - Google Cloud Console setup

## Support
Check the documentation files for detailed setup instructions.
