__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/c42e3039a77773ba.js",
  "static/chunks/turbopack-9bb0d03f1bac84e5.js"
])
