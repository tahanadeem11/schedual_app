__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/c42e3039a77773ba.js",
  "static/chunks/turbopack-2229bfee3a071ba9.js"
])
